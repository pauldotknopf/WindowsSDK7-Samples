using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;

namespace WCSamples
{
    /// <summary>
    /// Interaction logic for app.xaml
    /// </summary>

    public partial class app : Application
    {

    }
}