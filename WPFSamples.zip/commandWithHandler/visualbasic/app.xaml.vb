' Interaction logic for app.xaml
Partial Public Class app
    Inherits Application

End Class
