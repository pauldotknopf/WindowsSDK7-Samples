Imports System
    Friend NotInheritable Class MainEntry
        ' Methods
        <STAThread> _
        Public Shared Sub Main()
        Dim app As New MyApp
        app.Run()
        End Sub

    End Class


