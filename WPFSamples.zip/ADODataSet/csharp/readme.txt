
ADODataSetSample

Demonstrates filling a DataSet by connecting to an Access *.mdb file using
ADO API in the Loaded event

To run:
(1) Execute the CopyMDB.cmd. This copies the BookData.mdb to your
    "Application Data" folder, typically located at
    C:\Documents and Settings\YourAlias\Application Data/ADODataSetSample

(2) Using MSBUILD or from within Visual Studio build the sample using the
    csproj file and execute bin\debug\ADODataSetSample.exe
