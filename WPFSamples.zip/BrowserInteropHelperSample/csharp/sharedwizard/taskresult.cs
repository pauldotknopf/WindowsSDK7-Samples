namespace SharedPages
{
    using System;

    public enum TaskResult
    {
        Finished,
        Canceled
    }
}
