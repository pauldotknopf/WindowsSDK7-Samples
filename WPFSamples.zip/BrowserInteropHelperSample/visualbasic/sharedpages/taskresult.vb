Imports System

Namespace SharedPages
    Public Enum TaskResult
        Canceled = 1
        Finished = 0
    End Enum
End Namespace


