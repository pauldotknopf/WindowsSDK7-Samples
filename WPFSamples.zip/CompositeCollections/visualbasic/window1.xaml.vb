Imports System
Imports System.ComponentModel
Imports System.Windows
Imports System.Windows.Markup

Public Class Window1
    Inherits Window

    ' Methods
    Public Sub New()
        Me.InitializeComponent()
    End Sub

End Class


