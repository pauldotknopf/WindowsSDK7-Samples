Imports System

    Public Enum TempType
        ' Fields
        Celsius = 0
        Fahrenheit = 1
    End Enum


