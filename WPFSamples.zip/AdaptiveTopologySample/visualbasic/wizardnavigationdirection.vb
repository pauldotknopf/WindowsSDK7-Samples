Imports System

Namespace AdaptiveTopologySample
    Public Enum WizardNavigationDirection
        Forwards = 0
        Reverse = 1
    End Enum
End Namespace


