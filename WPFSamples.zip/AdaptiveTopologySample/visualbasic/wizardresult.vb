Imports System

Namespace AdaptiveTopologySample
    Public Enum WizardResult
        Canceled = 1
        Finished = 0
    End Enum
End Namespace


