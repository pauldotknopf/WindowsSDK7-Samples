using System;
using System.Collections.Generic;
using System.Text;

namespace AdaptiveTopologySample
{
    public enum WizardNavigationDirection
    {
        Forwards,
        Reverse
    }
}
