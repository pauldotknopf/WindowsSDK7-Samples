namespace AdaptiveTopologySample
{
    using System;

    public enum WizardResult
    {
        Finished,
        Canceled
    }
}
