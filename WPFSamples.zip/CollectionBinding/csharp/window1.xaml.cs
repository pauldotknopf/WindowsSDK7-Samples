using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Data;
using System.Windows.Media;
using System.Collections.ObjectModel;

namespace SDKSample
{    
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }
    }

}
