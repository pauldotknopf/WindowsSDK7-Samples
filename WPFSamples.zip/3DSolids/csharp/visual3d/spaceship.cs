using System;
using System.Collections.Generic;
using System.Text;

namespace Visual3DSample
{
    class SpaceShip
    {
    }
}
