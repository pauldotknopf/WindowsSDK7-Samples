//ParticleEffectsExample.h file

#pragma once

using namespace System;
using namespace System::Windows;
using namespace System::Windows::Controls;
using namespace System::Windows::Data;
using namespace System::Windows::Documents;
using namespace System::Windows::Media;
using namespace System::Windows::Navigation;
using namespace System::Windows::Shapes;
using namespace System::Collections::Generic;
using namespace System::Collections;

namespace Microsoft {
	namespace Samples {
		namespace PerFrameAnimations {
			public ref class ParticleEffectExamples : Page {
				public:
               ParticleEffectExamples () ;
			};
		}
	}
}

