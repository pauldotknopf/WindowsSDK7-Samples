using System.Runtime.InteropServices;

// Managed definition for external COM interface
[Guid("9D208F9D-7DD3-4830-891D-5E2F58A1F749")]
interface ILogWriter
{
   void Write();
}
