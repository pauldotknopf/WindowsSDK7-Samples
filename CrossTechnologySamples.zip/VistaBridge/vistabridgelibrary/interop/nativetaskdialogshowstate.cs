using System;

namespace Microsoft.SDK.Samples.VistaBridge.Interop
{
    internal enum NativeDialogShowState
    {
        PreShow,
        Showing,
        Closing, 
        Closed
    }
}
