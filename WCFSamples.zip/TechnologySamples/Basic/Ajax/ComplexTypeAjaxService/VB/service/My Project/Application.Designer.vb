' Copyright (c) Microsoft Corporation. All rights reserved.

Option Strict On
Option Explicit On

