Summary description 
--------------------
This sample highlights the key features of LINQ querying(Standard Query operators).This sample does 

1)Lists the contents of the FIle System in a treeview and lets the user search through the items in the TreeView using LINQ queries (using custom Extension methods)

2)Groups the contents of a directory by Extension (using LINQ Group By operator)


Build requirements
------------------
1. Visual Studio 2008 (Orcas) with .NET Compact Framework installed.



How to build
------------
Open the solution with Visual Studio 2008 and run the project. 